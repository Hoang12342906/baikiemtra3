package com.example.apptonghop;

public class Gridview_Food {
    private int Hinhgridview;
    private String Tenfood;

    public Gridview_Food(int hinhgridview, String tenfood) {
        Hinhgridview = hinhgridview;
        Tenfood = tenfood;
    }

    public int getHinhgridview() {
        return Hinhgridview;
    }

    public void setHinhgridview(int hinhgridview) {
        Hinhgridview = hinhgridview;
    }

    public String getTenfood() {
        return Tenfood;
    }

    public void setTenfood(String tenfood) {
        Tenfood = tenfood;
    }
}
